import java.util.HashSet;
import java.util.Set;

import org.ycpait.studentManagementpp.entity.*;
public class DemoHashCodeEquals {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Student> students=new HashSet<Student>();
////		Student s1=new Student("Amit",88);
////		Student s2=new Student("Ait",88);
//		
//		students.add(s2);
//		students.add(s1);
//		System.out.println(s1);
//		System.out.println(s2);
//		System.out.println(s1.equals(s2));
//		System.out.println(students.size());
	}

}
